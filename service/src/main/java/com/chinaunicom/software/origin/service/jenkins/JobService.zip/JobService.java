package com.chinaunicom.software.origin.service.jenkins;

import com.aio.portable.swiss.global.Constant;
import com.chinaunicom.software.origin.common.jenkins.JenkinsServerFactory;
import com.chinaunicom.software.origin.common.jenkins.script.node.*;
import com.chinaunicom.software.origin.common.jenkins.script.node.steps.build.StepsMaven;
import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.client.JenkinsHttpClient;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class JobService {
    private JenkinsServerFactory jenkinsServerFactory;
    private JenkinsServer jenkinsServer;
    private JenkinsHttpClient jenkinsHttpClient;

//    public JobService(JenkinsServerFactory jenkinsServerFactory) {
//        this.jenkinsServerFactory = jenkinsServerFactory;
//        this.jenkinsServer = jenkinsServerFactory.server();
//        this.jenkinsHttpClient = jenkinsServerFactory.client();
//    }

    public PipelineObject buildDemo1() {
        Steps steps1 = new Steps();
        steps1.setBlock("echo 'initial....'" + Constant.LINE_SEPARATOR + "echo 'build....'" + Constant.LINE_SEPARATOR);
        steps1.setScript(new Script() {{
            setBlock("echo 'this is some scripts.'");
        }});

        Stage stage1 = new Stage();
        stage1.setName("stage1");
        stage1.setSteps(steps1);

        Stage stage2 = new Stage();
        stage2.setName("Build");

        Stage stage3 = new Stage();
        stage3.setName("Test");
        stage3.setFailFast(true);

        List<Stage> stageList = new ArrayList<>();
        stageList.add(stage2);
        stageList.add(stage3);

        Parallel parallel = new Parallel();
        parallel.setStageList(stageList);

        stage1.setParallel(parallel);

        Stages stages = new Stages();
        stages.setStage(stage1);

        Triggers triggers = new Triggers();
        triggers.setBlock("cron('H 4/* 0 0 1-5')");

        Pipeline pipeline = new Pipeline();
        pipeline.setStages(stages);
        pipeline.setAgent("any");
        pipeline.setTriggers(triggers);

        PipelineObject pipelineScript = new PipelineObject();
        pipelineScript.setPipeline(pipeline);

        return pipelineScript;
    }

    public PipelineObject buildDemo2() {
        /*
          stages
            stage('Check')
              stages
                stage('Sonar')
            stage('Code')
              stages
                parallel
                  stage('GitLabDependency')
                  stage('GitHubPayCenter')
            stage('Build')
              stage('Maven')
            stage('Upload')
              stage('Habor')
            stage('Deploy')
              stage('Habor')
            stage('Test')
              stage('JUnit')
            stage('Publish')
              stage('BlueGreen')
         */

        Steps steps = new Steps();
        steps.setBlock("echo 'initial....'" + Constant.LINE_SEPARATOR + "echo 'build....'" + Constant.LINE_SEPARATOR);
        steps.setScript(new Script() {{
            setBlock("echo 'this is some scripts.'");
        }});

        Stage stageSonar = new Stage();
        stageSonar.setName("Sonar");
        stageSonar.setSteps(steps);

        Stage stageCQM1 = new Stage();
        stageCQM1.setName("CQM");
        stageCQM1.setSteps(steps);
        Stage stageCQM2 = new Stage();
        stageCQM2.setName("CQM");
        stageCQM2.setSteps(steps);

        List<Stages> checkStagesList = new ArrayList<>();
        checkStagesList.add(new Stages(stageCQM1, stageCQM2));
        checkStagesList.add(new Stages(stageSonar));
        Stage stageCheck = new Stage();
        stageCheck.setName("Check");
        stageCheck.setParallel(new Parallel(){{setStagesList(checkStagesList);}});

        Stage stageDependency = new Stage();
        stageDependency.setName("Dependency");

        Stage stagePayCenter = new Stage();
        stagePayCenter.setName("PayCenter");

        Stage stageCode = new Stage();
        stageCode.setName("Code");
        stageCode.setParallel(new Parallel(){{setStages(new Stages(stageDependency, stagePayCenter));}});

        StepsMaven stepsMaven = new StepsMaven();
        stepsMaven.setModule("api");
        stepsMaven.setOutputFile("order-management.jar");
        stepsMaven.setWorkDirectory("./");

        Stage stageMaven = new Stage();
        stageMaven.setName("Maven");
        stageMaven.setSteps(stepsMaven);


        Stage stageBuild = new Stage();
        stageBuild.setName("Build");
        stageBuild.setParallel(new Parallel(){{setStages(new Stages(stageMaven));}});
//        stageBuild.setStages(new Stages(stageMaven));

        Stage stageHarbor = new Stage();
        stageHarbor.setName("Harbor");

        Stage stageUpload = new Stage();
        stageUpload.setName("Upload");
//        stageUpload.setStages(new Stages(stageHarbor));
        stageUpload.setParallel(new Parallel(){{setStages(new Stages(stageHarbor));}});

        Stage stageK8s = new Stage();
        stageK8s.setName("K8s");

        Stage stageDeploy = new Stage();
        stageDeploy.setName("Deploy");
//        stageDeploy.setStages(new Stages(stageK8s));
        stageDeploy.setParallel(new Parallel(){{setStages(new Stages(stageK8s));}});

        Stage stageJUnit = new Stage();
        stageJUnit.setName("JUnit");

        Stage stageTest = new Stage();
        stageTest.setName("Test");
//        stageTest.setStages(new Stages(stageJUnit));
        stageTest.setParallel(new Parallel(){{setStages(new Stages(stageJUnit));}});

        Stage stageBlueGreen = new Stage();
        stageBlueGreen.setName("BlueGreen");

        Stage stagePublish = new Stage();
        stagePublish.setName("Publish");
        stagePublish.setParallel(new Parallel(){{setStages(new Stages(stageBlueGreen));}});
//        stagePublish.setStages();
//        stagePublish.setStages(new Stages(stageBlueGreen));/////////////////////

        Stages stages = new Stages(stageCheck, stageCode, stageBuild, stageUpload, stageDeploy, stageTest, stagePublish);

        Triggers triggers = new Triggers();
        triggers.setBlock("cron('H 4/* 0 0 1-5')");

        Pipeline pipeline = new Pipeline();
        pipeline.setAgent("any");
        pipeline.setTriggers(triggers);
        pipeline.setStages(stages);

        PipelineObject pipelineScript = new PipelineObject();
        pipelineScript.setPipeline(pipeline);

        return pipelineScript;
    }

    public void build(String jobName, PipelineObject pipelineScript) {
        String jobXml = "";
        try {
            jenkinsServer.createJob(jobName, jobXml);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public void update(String jobName, PipelineObject pipelineScript) {
        String jobXml = "";
        try {
            jenkinsServer.updateJob(jobName, jobXml);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

}
